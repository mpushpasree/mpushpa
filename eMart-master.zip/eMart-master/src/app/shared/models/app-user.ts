
export interface AppUser { 
  name: string;
  email: string;
  photo: string; 
  isAdmin: boolean;
}
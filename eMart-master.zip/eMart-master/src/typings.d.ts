/* SystemJS module definition */
declare var module: NodeModule;
declare var Masonry: any;
declare var Isotope: any;
interface NodeModule {
  id: string;
}

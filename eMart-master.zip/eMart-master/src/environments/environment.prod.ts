export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCokDdCHAVGtWx3BqrYpEDRwRAkC6nCXbg",
    authDomain: "emart-205419.firebaseapp.com",
    databaseURL: "https://emart-205419.firebaseio.com",
    projectId: "emart-205419",
    storageBucket: "emart-205419.appspot.com",
    messagingSenderId: "880926318228"
  }
};
